# تطبيق حساباتي

هذا مشروع Android جاهز للاستيراد في Android Studio، ويضم نسخة HTML المرفوعة داخل التطبيق.

## إنشاء APK
1. افتح المجلد في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر Build > Build APK(s).
4. ستجد APK داخل:
   app/build/outputs/apk/debug/

التطبيق يعمل بدون إنترنت ويحتفظ بالبيانات باستخدام localStorage داخل WebView.
